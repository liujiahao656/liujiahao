<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\IndexController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
use App\Http\Controllers\Admin\UserController;
Route::get('/admin/login', [UserController::class, 'login']);
Route::post('/admin/check', [UserController::class, 'check']);
Route::get('/admin/logout', [UserController::class, 'logout']);
Route::get('/admin/index', [IndexController::class, 'index'])->middleware('Admin');
Route::prefix('category')->middleware('Admin')->group(function () {
    Route::get('/add', [App\Http\Controllers\Admin\CategoryController::class, 'add']);
    // 其他分类相关路由可以在这里添加
});