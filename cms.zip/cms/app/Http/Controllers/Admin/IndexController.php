<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB; 
class IndexController extends Controller
{
    public function index(Request $request)
    {
        $data = [
            'server_version' => $request->server('SERVER_SOFTWARE'),
            'laravel_version' => app()::VERSION,
            'mysql_version' => $this->getMysqlVer(),
            'server_time' => date('Y-m-d H:i:s', time()),
            'upload_max_filesize' => ini_get('file_uploads') ? ini_get('upload_max_filesize') : '已禁用',
            'max_execution_time' => ini_get('max_execution_time') . '秒',
        ];
        return view('admin\index' ,$data);
    }
    private function getMysqlVer()
    {
        $res = DB::select('SELECT VERSION() as ver');
        return $res[0]->ver ?? '未知';
    } 
}
