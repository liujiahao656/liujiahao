<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAdminUserTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
{
    Schema::create('admin_user', function (Blueprint $table) {
        $table->increments('id')->comment('主键');
        $table->string('username', 32)->comment('用户名')->unique();
        $table->string('password', 32)->comment('密码');
        $table->char('salt', 32)->comment('密码salt');
        $table->timestamps();
    });
}


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('admin_user');
    }
}
