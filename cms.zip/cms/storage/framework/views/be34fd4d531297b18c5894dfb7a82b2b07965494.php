
<?php $__env->startSection('title', '后台首页'); ?>
<?php $__env->startSection('main'); ?>
<div class="main-title">
    <h2>首页</h2>
</div>
<div class="main-section">
    <div class="card">
        <div class="card-header">服务器信息</div>
        <ul class="list-group list-group-flush">
            <li class="list-group-item">系统环境: <?php echo e($server_version); ?></li>
            <li class="list-group-item">laravel版本：<?php echo e($laravel_version); ?></li>
            <li class="list-group-item">mysql版本：<?php echo e($mysql_version); ?></li>
            <li class="list-group-item">服务器时间：<?php echo e($server_time); ?></li>
            <li class="list-group-item">文件上传限制：<?php echo e($upload_max_filesize); ?></li>
            <li class="list-group-item">脚本执行时限：<?php echo e($max_execution_time); ?></li>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpstudy_pro\WWW\cms\resources\views/admin\index.blade.php ENDPATH**/ ?>