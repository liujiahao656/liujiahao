<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>登录</title>
  <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/common/twitter-bootstrap/4.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/common/font-awesome-4.2.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/common/toastr.js/2.1.4/toastr.min.css">
  <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/css/main.css">
  <script src="<?php echo e(asset('admin')); ?>/common/jquery/1.12.4/jquery.min.js"></script>
  <script src="<?php echo e(asset('admin')); ?>/common/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <script src="<?php echo e(asset('admin')); ?>/common/toastr.js/2.1.4/toastr.min.js"></script>
  <script src="<?php echo e(asset('admin')); ?>/js/main.js"></script>
</head>

<body class="login">
  <div class="container">
    <form action="<?php echo e(url('admin/check')); ?>" method="post" class="j-login">
      <h1>后台管理系统</h1>
      <div class="form-group">
        <input type="text" name="username" class="form-control" placeholder="用户名" required>
      </div>
      <div class="form-group">
        <input type="password" name="password" class="form-control" placeholder="密码" required>
      </div>
      <div class="form-group">
        <input type="text" name="captcha" class="form-control" placeholder="验证码" required>
      </div>
      <div class="form-group">
        <div class="login-captcha"><img src="<?php echo e(captcha_src()); ?>" alt="captcha"></div>
      </div>
      <div class="form-group">
        <?php echo e(csrf_field()); ?>

        <input type="submit" class="btn btn-lg btn-block btn-success" value="登录">
      </div>
    </form>
  </div>
  <script>
    $('.login-captcha img').on('click', function() {
      $(this).attr('src', '<?php echo e(captcha_src()); ?>' + '?' + Math.random());
    });
    main.ajaxForm('.j-login', function() {
      location.href = 'index';
    });
  </script>
</body>

</html><?php /**PATH D:\phpstudy_pro\WWW\cms\resources\views/admin/login.blade.php ENDPATH**/ ?>