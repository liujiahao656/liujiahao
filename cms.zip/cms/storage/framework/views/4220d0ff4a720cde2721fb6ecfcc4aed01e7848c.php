
<?php $__env->startSection('title', '添加栏目'); ?>
<?php $__env->startSection('main'); ?>
<div class="main-title"><h2>添加栏目</h2></div>
<div class="main-section">
    <div style="width: 543px;">
        <!-- 添加栏目 -->
         <form action="<?php echo e(url('category/save')); ?>" method="post">
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">序号</label>
                <div class="col-sm-10">
                    <input type="number" name="sort" class="form-control" value="0" style="width: 80px;">
                </div>
            </div>
         </form>
    </div>
</div>
<script>
    main.menuActive( 'addcategory');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpstudy_pro\WWW\cms\resources\views/admin/category/add.blade.php ENDPATH**/ ?>